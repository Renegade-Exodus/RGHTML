                                R G T E R M
                          Linux build - read me first

==============================================================================
1. WHAT THIS IS
==============================================================================

A native Linux build of RGTERM (x86_64), compiled from the same source as
the Windows version. It is not running under Wine: windows, keyboard,
mouse, sound, networking, clipboard and fullscreen all go through SDL2
and the normal Linux APIs.

Everything in RGTERM.TXT applies, with the Linux-specific notes below.


==============================================================================
2. REQUIREMENTS
==============================================================================

  - 64-bit x86 Linux with glibc 2.34 or newer (Ubuntu 22.04+, Debian 12+,
    Linux Mint 21+, Fedora 35+, current Arch/Manjaro/openSUSE).
  - A graphical desktop (X11 or Wayland).
  - SDL2 (required). Everything else is optional and only needed for the
    feature listed next to it - RGTERM simply turns that feature off if
    the library isn't there, exactly like a missing DLL on Windows.

  Ubuntu 24.04 / Mint 22 / Debian 13:
    sudo apt install libsdl2-2.0-0 libssl3t64 libssh2-1t64 libvorbisfile3 \
                     libmpg123-0t64 xdg-utils

  Ubuntu 22.04 / Mint 21 / Debian 12:
    sudo apt install libsdl2-2.0-0 libssl3 libssh2-1 libvorbisfile3 \
                     libmpg123-0 xdg-utils

  Fedora:
    sudo dnf install SDL2 openssl-libs libssh2 libvorbis mpg123-libs xdg-utils

  Arch:
    sudo pacman -S sdl2 openssl libssh2 libvorbis mpg123 xdg-utils

  What each optional library is for:
    libssl3 ........ Telnet over TLS (telnets), HTTPS downloads (BBS guide)
    libssh2 ........ SSH connections
    libvorbisfile .. OGG sounds from doors
    libmpg123 ...... MP3 internet-radio / URL audio (the Windows build uses
                     the Windows MP3 codec for this)
    libjxl ......... JPEG XL images
    speech-dispatcher (spd-say) ... Alt+R screen-reader mode
    xdg-utils ...... opening clicked links in your web browser


==============================================================================
3. INSTALLING AND RUNNING
==============================================================================

RGTERM is "portable" on Linux just as on Windows: it keeps its phonebook,
settings, downloads and scripts in the folder it runs from. So:

  1. Extract this archive somewhere in your home folder, e.g. ~/rgterm
  2. Copy these folders from your Windows RGTERM folder into it (they are
     the same on both systems):
         fonts\   icons\   doors\   ooii\   scripts\
     Without fonts\ RGTERM still runs, using its built-in fallback font.
  3. Optionally copy rgterm.ini (your phonebook) and rgterm_config.ini
     (your settings) too - both files work unchanged on Linux. Folder
     settings written Windows-style ("downloads\bbs") are understood.
  4. Run it:   cd ~/rgterm && ./rgterm

  Menu entry: run ./install-desktop-entry.sh once to add RGTERM to your
  desktop's application menu, with its icon.

  Don't install it into a system folder like /usr/bin or /opt - it needs
  to be able to write next to itself.


==============================================================================
4. WHAT'S DIFFERENT ON LINUX
==============================================================================

  Alt+J (Shell to DOS)
      Opens your terminal emulator (gnome-terminal, konsole, xfce4-terminal,
      kitty, alacritty, xterm, ... or whatever $TERMINAL names) and waits
      for it to close.

  Phonebook "Shell" connection type
      Runs a real shell inside RGTERM through a Linux pseudo-terminal.
      Leave Shell Command blank for your login shell ($SHELL), or type
      any command line (it runs through /bin/sh -c). The shell sees
      TERM=ansi, which matches how RGTERM wraps text.

  External doors (Ctrl+F1..F10, Alt-C page 3)
      The command line is an ordinary shell command, e.g.
          dosbox -conf ~/gterm/gterm.conf
      %HOST% %PORT% %USER% %PASSWORD% are filled in as on Windows.

  Serial bridge for external doors
      Easiest on Linux: use the TCP bridge - set the bridge port to a
      number (e.g. 6400) and point DOSBox's serial port at it:
          serial1=nullmodem server:127.0.0.1 port:6400
      A real or virtual serial device also works: enter its path
      (/dev/ttyUSB0, /dev/pts/5 ...). "COM5" means /dev/ttyS4.

  File browser (Alt+U, Alt+I, ...)
      F6 cycles /, your home folder and mounted drives (/media/<you>/*,
      /run/media/<you>/*, /mnt/*) instead of drive letters. F5 (jump)
      accepts ~/ and $HOME-style paths as well as %VAR%.

  Alt+R screen-reader mode
      Speaks through speech-dispatcher, the same speech service Orca uses.

  Fullscreen (Alt+Enter), Screen Scale, drag-resize with aspect snap,
  drag-and-drop upload, Alt+P screenshots, copy (mouse drag) / paste
  (right-click), ANSI music, door sounds - all work as on Windows.


==============================================================================
5. KNOWN LIMITATIONS
==============================================================================

  - 64-bit x86 only. For a Raspberry Pi or other ARM board.
  - Importing PuTTY sessions reads PuTTY's Windows registry export only,
    not ~/.putty/sessions.
  - The door relay viewer window (sysop mode) draws with RGTERM's own
    bitmap font rather than a Windows TrueType font.
