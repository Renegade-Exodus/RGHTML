RGTERM for Linux - Version 1.10
===============================


Running
-------
  Needs the SDL2 runtime library (libSDL2-2.0.so.0), loaded at run time:
      Debian/Ubuntu:  sudo apt install libsdl2-2.0-0
      Fedora:         sudo dnf install SDL2
  Keep rgterm next to RGTERM.ico and the fonts/ folder. Settings and the
  phonebook are stored beside the program, as on Windows.

Optional run-time libraries / tools (features degrade quietly without them)
  libmpg123.so.0      MP3 URL audio
  libssh2, OpenSSL    SSH and TLS connections (libssh2.so.1, libssl.so.3)
  libvorbisfile, libjxl   OGG / JPEG XL support
  espeak-ng (or espeak, spd-say)   screen-reader speech (Alt+R)
  zenity or kdialog   file-open dialog
  xdg-open            opening links

Differences from Windows
------------------------
  * Serial/COM ports use device paths such as /dev/ttyUSB0.
  * External doors and the command-line connection type run through
    /bin/sh.
  * Drive-letter cycling in the file browser does nothing.
