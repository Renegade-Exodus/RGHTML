#!/bin/sh
# Adds RGTERM to your desktop's application menu (for the current user).
# Run it from the folder RGTERM lives in; re-run it if you move the folder.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$HOME/.local/share/applications" "$HOME/.local/share/icons/hicolor/256x256/apps"
cp "$DIR/rgterm.png" "$HOME/.local/share/icons/hicolor/256x256/apps/rgterm.png"
cat > "$HOME/.local/share/applications/rgterm.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=RGTERM
GenericName=BBS Terminal
Comment=BBS terminal emulator (ANSI, RIP, Zmodem, SSH)
Exec="$DIR/rgterm"
Path=$DIR
Icon=rgterm
Terminal=false
Categories=Network;TerminalEmulator;
DESK
update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1 || true
echo "RGTERM added to your application menu."
