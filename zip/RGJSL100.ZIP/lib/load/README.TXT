LIB\LOAD - JavaScript library files from Synchronet BBS (exec/load), UNMODIFIED.

These are the plain-JavaScript helper libraries Synchronet doors load()
(frame.js, sprite.js, layout.js, event-timer.js, tree.js, funclib.js,
sbbsdefs.js, ...).  They are included so native Synchronet JS doors can
drop in and run under RGJS.  No Synchronet programs or DLLs are used: RGJS
supplies the console/bbs/system/user objects these files call into.

RGJS looks in LIB\ before LIB\LOAD\, so RGJS's own versions win where they
exist: dorkit.js, recordfile.js, array.js and json-client.js (local scores,
no network).

Source : https://github.com/SynchronetBBS/sbbs  (exec/load), taken 2026-11-12
License: Synchronet is free software - see http://www.synchro.net/copyright.html
         (GNU GPL).  Copyright Rob Swindell and the Synchronet contributors.
