RGJS for Linux (also runs under WSL)
====================================

Files
  rgjs             the program (64-bit)
  libduktape.so    the JavaScript engine - keep it beside rgjs
  lib/             runtime scripts; lib/load/ holds the Synchronet library
                   files.  Keep both beside rgjs.

Install
  unzip RGJS-LINUX.zip -d ~/rgjs
  chmod +x ~/rgjs/rgjs
  (rgjs finds libduktape.so next to itself - no LD_LIBRARY_PATH needed)

  Optional, for https feeds (NewsCenter etc.):
    sudo apt install libssl3        (Debian/Ubuntu)

Run a door locally (you are the caller)
  cd /path/to/door
  ~/rgjs/rgjs -L lord.js

Run from a BBS
  ~/rgjs/rgjs -D /path/to/node/door32.sys /path/to/door/lord.js
    DOOR32.SYS line 2 = socket handle the BBS passes in.
    DOOR.SYS also works (-D /path/DOOR.SYS) for stdio doors.

Options
  -D<file>  dropfile (DOOR32.SYS or DOOR.SYS)
  -L        local mode, console is the caller
  -N        no local sysop screen
  -R        raw socket (no telnet processing)
  -A        use alias as the player's name
  -V        verbose log      -Q  no log
  Extra words after the script go to the door (e.g. war.js worlds/earth)

Created at run time beside rgjs
  RGJS.LOG    errors and warnings
  ctrl/       Synchronet-style ctrl dir (modopts.d)
  data/user/  per-user marker files (TradeWars 2)

Doors keep their saved data in their own folder (json/ for scoreboards and
TradeWars 2).  See RGJS.TXT for the door list and per-door notes.
