; ============================================================
; RGBASE message base template  (sample - make your own with RGBASE EXPORT))
; Use:  RGBASE MSG "Name" FILENAME  [/T:this.tpl]
; Name and FileName come from the command / MSG.TXT.
; Lines starting with ; are comments.  Blank value = none.
; ============================================================

; Access ACS - who can see/read the base (blank = everyone)
; examples: s20   (SL 20+)   fA   (flag A)   s50&fB
ACS=
; Post ACS - who can post (blank = anyone with access)
PostACS=
; MCI ACS - who can use MCI codes in posts
MCIACS=
; SysOp ACS - who is message SysOp for this base
SysOpACS=s255

; Max messages kept (1-65535, older ones packed off)
MaxMsgs=100
; Anonymous posts:  No | Yes | Forced | DearAbby | AnyName
Anonymous=No
; Password to enter the base (blank = none)
Password=

; Base type:  0 = Local   1 = Echomail   2 = Group (netmail)   3 = QWK
MAType=0
; Echomail .MSG directory (MAType 1/2 only).  @F = FileName.
; Created if missing.  Blank on a local base.
MsgPath=
; Flags - comma separated, any of:
;   RealName  force real names       UnHidden  show to users w/o access
;   Filter    filter ANSI/8-bit      Private   allow private msgs
;   ForceRead must read in newscan   Quote     allow quote/taglines
;   SKludge   strip kludge lines     SSeenBy   strip SEEN-BY lines
;   SOrigin   strip origin lines     AddTear   add tear/origin lines
;   Internet  internet base          ScanOut   needs scan-out by RENEMAIL
; echomail usually: AddTear,SSeenBy
Flags=
; Origin line (echomail).  Blank = system default origin.
Origin=

; Colors - Renegade color number, as set in the Message Editor
TextColor=0
QuoteColor=0
TearColor=0
OriginColor=0
; Message read menu number (0 = default read menu)
MessageReadMenu=0
; Quote header lines.  @F = from  @T = to  @D = date.  ^0-^9 colors.
QuoteStart=^0Quoting message from ^1@F ^0to ^1@T^0
QuoteEnd=^0on ^1@D ^0...
; File shown before posting (8 chars, no extension, blank = none)
PrePostFile=
; Network address to use: 0 = main address, 1-n = AKA number
AKA=0
