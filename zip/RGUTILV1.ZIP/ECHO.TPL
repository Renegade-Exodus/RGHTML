; ============================================================
; RGBASE echomail template (sample)
; Use:  RGBASE MSG "Name" FILENAME /T:ECHO.TPL
; Any key left out comes from MBASES.DEF (Message Editor, X).
; Full list of keys and options: see MSGBASE.TPL
; ============================================================

; Access / post / sysop ACS (blank = everyone)
ACS=
PostACS=
SysOpACS=s255
; Max messages kept
MaxMsgs=500
; No | Yes | Forced | DearAbby | AnyName
Anonymous=No
; 0 = Local  1 = Echomail  2 = Group  3 = QWK
MAType=1
; Echomail .MSG directory, @F = FileName (created if missing)
MsgPath=D:\RG\ECHO\@F\
; AddTear,SSeenBy,ScanOut etc. - see MSGBASE.TPL
Flags=AddTear,ScanOut,SSeenBy
; Origin line, blank = system default
Origin=
; 0 = main address, 1-n = AKA number
AKA=0
