; ============================================================
; RGBASE file base template  (sample - make your own with RGBASE EXPORT)
; Use:  RGBASE FILE "Name" FILENAME  [/T:this.tpl]
; Name and FileName come from the command / FILE.TXT.
; Lines starting with ; are comments.  Blank value = none.
; ============================================================

; Download path - where the files are.  @F = FileName.
; Created if missing.  /DL: on the command line overrides.
DLPath=D:\RG\FILES\@F\
; Upload path - where new uploads go (often one shared dir).
ULPath=D:\RG\FILES\@F\
; Max files in the area (1-32767)
MaxFiles=2000
; Password to enter the area (blank = none)
Password=

; Archive type uploads are converted to.  0 = none (leave as is)
; Archivers on your BBS:
;   1-8 = archiver # from System Config (EXPORT FILE lists yours)
ArcType=0
; Comment file added to archives.  0 = none
;   1-3 = comment file # from System Config (EXPORT FILE lists yours)
CmtType=0

; Access ACS - who can see the area (blank = everyone)
; examples: s20   (SL 20+)   d30  (DSL 30+)   fA  (flag A)
ACS=
; Upload ACS - who can upload here
ULACS=
; Download ACS - who can download here
DLACS=

; Flags - comma separated, any of:
;   NoRatio     no UL/DL ratio        UnHidden    show to users w/o access
;   DirDLPath   .DIR file in DLPath   ShowName    show uploader name
;   UseGIFSpecs show GIF sizes        CDROM       read only, no sort/UL scan
;   ShowDate    show upload date      NoDupeCheck skip dupe check
; example: Flags=NoRatio,ShowDate
Flags=
