This is an upgrade from v1.40/DOS to v1.44/DOS or /Win32 or /Linux

With that being said, BACK UP BACK UP BACK UP! before anything is done!

Select when Update program you wish to run, DOS, Windows, Linux.  They
all do the same thing.

If some reason the upgrade fails, unzip the build .RGD file you want and
manually place them in their proper directories overwriting/replacing
the current files here.

Run RGSETUP for a lightbar driven config manager to change paths and
update information within Renegade without loading Renegade.

ENJOY!
